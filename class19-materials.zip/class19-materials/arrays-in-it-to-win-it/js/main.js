//Create an array of movies with at least three movies.

//Using the array from above, store the first movie in a variable

//Get the length of the original array and store it in a new variable

//Get the last element in that array and store it in a new variable. What if your array was really large and you didn't know the last index? Would your solution still work?
