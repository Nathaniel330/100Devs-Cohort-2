//Get a dog photo from the dog.ceo api and place the photo in the DOM
