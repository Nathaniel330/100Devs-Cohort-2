//create a function that adds two numbers and alerts the sum

//create a function that multiplys three numbers and console logs the product

//create a function that divides two numbers and returns the ???
